import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth } from '../../../core/services/authService';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
   loginForm: FormGroup;
   submitted = false;

   constructor(private fbuilder: FormBuilder, private authService: Auth) {
        this.loginForm = this.fbuilder.group({
          email: ['',[Validators.required,Validators.email]],
          password: ['',[Validators.required,Validators.minLength(8)]]
        });
   }

   get f() {
      return this.loginForm.controls;
   }

   onSubmit() {
      this.submitted = true;

      if(this.loginForm.invalid) {
        return;
      }

      this.authService.login(this.loginForm.value).subscribe({
        next: (response) => {
          const token = response.token;

          if(token) {
            console.log(token);
            localStorage.setItem('token',token);
            alert("Login Successfull");
          }else {
            alert("Login Failed!!");
          }

          this.loginForm.reset();
          this.submitted = false;
        },
      error: (error) => {
            console.error('Login error:', error.error.message);
            alert('Login failed:');
          }
      });

      // console.log("Form Value:", this.loginForm.value);
      //  alert('Registration Successful!');
      //  this.loginForm.reset();
      //  this.submitted = false;
   }
}
