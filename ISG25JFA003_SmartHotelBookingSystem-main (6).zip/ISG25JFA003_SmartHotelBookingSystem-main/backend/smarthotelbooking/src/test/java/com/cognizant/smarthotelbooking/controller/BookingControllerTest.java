package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.BookingRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.service.BookingService;
import com.cognizant.smarthotelbooking.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BookingController.class)
public class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookingService bookingService;

    @MockBean
    private JwtUtil jwtUtil;

    @Autowired
    private ObjectMapper objectMapper;

    private long testBookingId;
    private BookingRequestDTO mockBookingRequestDTO;
    private BookingResponseDTO mockBookingResponseDTO;
    private BookingRoomResponseDTO mockBookingRoomResponseDTO;
    private List<BookingResponseDTO> mockBookingResponseDTOList;

    @BeforeEach
    void setUp() {
        testBookingId = 1L;
        mockBookingRequestDTO = new BookingRequestDTO(
                101L,
                LocalDate.of(2025, 9, 27),
                LocalDate.of(2025, 9, 29)
        );

        mockBookingResponseDTO = new BookingResponseDTO(
                testBookingId,
                1L,
                101L,
                LocalDate.of(2025, 9, 27),
                LocalDate.of(2025, 9, 29),
                LocalDate.of(2025, 9, 22),
                250.00,
                null
        );

        mockBookingRoomResponseDTO = new BookingRoomResponseDTO(
                testBookingId,
                1L,
                "Test User",
                101L,
                "Single Room",
                LocalDate.of(2025, 9, 27),
                LocalDate.of(2025, 9, 29),
                LocalDate.of(2025, 9, 22),
                null
        );

        mockBookingResponseDTOList = Collections.singletonList(mockBookingResponseDTO);
    }

    @Test
    @WithMockUser
    void createBooking_shouldReturnCreated() throws Exception {
        when(bookingService.createBooking(any(BookingRequestDTO.class))).thenReturn(mockBookingResponseDTO);

        mockMvc.perform(post("/api/bookings/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(mockBookingRequestDTO))
                        .with(csrf()))
                .andExpect(status().isOk()) // <-- CORRECTED: Asserts for 200 OK to match the controller's implementation
                .andExpect(jsonPath("$.bookingId", is(1)))
                .andExpect(jsonPath("$.roomId", is(101)));

        verify(bookingService, times(1)).createBooking(any(BookingRequestDTO.class));
    }

    @Test
    @WithMockUser
    void getBookingById_shouldReturnBooking() throws Exception {
        when(bookingService.getBookingById(testBookingId))
                .thenReturn(mockBookingRoomResponseDTO);

        mockMvc.perform(get("/api/bookings/{bookingId}", testBookingId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bookingId", is(1)))
                .andExpect(jsonPath("$.roomId", is(101)));

        verify(bookingService, times(1)).getBookingById(testBookingId);
    }

    @Test
    @WithMockUser
    void getBookingsByUserId_shouldReturnListOfBookings() throws Exception {
        when(bookingService.getBookingsByUserId(1L)).thenReturn(mockBookingResponseDTOList);

        mockMvc.perform(get("/api/bookings/user/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bookingId", is(1)))
                .andExpect(jsonPath("$[0].roomId", is(101)));

        verify(bookingService, times(1)).getBookingsByUserId(1L);
    }

    @Test
    @WithMockUser
    void updateBooking_shouldReturnOk() throws Exception {
        doNothing().when(bookingService).updateBooking(eq(String.valueOf(testBookingId)), any(BookingRequestDTO.class));

        mockMvc.perform(put("/api/bookings/{bookingId}", testBookingId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(mockBookingRequestDTO))
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(content().string("Booking updated successfully."));

        verify(bookingService, times(1)).updateBooking(eq(String.valueOf(testBookingId)), any(BookingRequestDTO.class));
    }

    @Test
    @WithMockUser
    void cancelBooking_shouldReturnNoContent() throws Exception {
        doNothing().when(bookingService).cancelBooking(String.valueOf(testBookingId));

        mockMvc.perform(delete("/api/bookings/{bookingId}", testBookingId)
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(content().string("Booking cancelled successfully."));

        verify(bookingService, times(1)).cancelBooking(String.valueOf(testBookingId));
    }

    @Test
    @WithMockUser
    void getBookingById_shouldReturnNotFound_whenBookingDoesNotExist() throws Exception {
        when(bookingService.getBookingById(eq(999L)))
                .thenThrow(new BookingNotFoundException("Booking with ID 999 not found."));

        mockMvc.perform(get("/api/bookings/{bookingId}", 999L))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message", is("Booking with ID 999 not found.")));

        verify(bookingService, times(1)).getBookingById(999L);
    }
}