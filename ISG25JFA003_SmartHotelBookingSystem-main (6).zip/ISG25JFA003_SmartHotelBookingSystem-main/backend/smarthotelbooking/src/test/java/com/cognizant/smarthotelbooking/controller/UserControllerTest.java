package com.cognizant.smarthotelbooking.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import com.cognizant.smarthotelbooking.entity.enums.Role;
import com.cognizant.smarthotelbooking.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    private MockMvc mockMvc;

    @Mock
    private UserServiceImpl userService;

    @InjectMocks
    private UserController userController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testWelcomeUser() throws Exception {
        mockMvc.perform(get("/api/user/welcome-user"))
                .andExpect(status().isOk())
                .andExpect(content().string("Welcome to protected route"));
    }

    @Test
    void testGetUserById() throws Exception {
        // Arrange
        UserResponseDTO userResponseDTO = new UserResponseDTO(1L, "Test User", "test@example.com", Role.USER, "1234567890");
        when(userService.getUserById(1L)).thenReturn(userResponseDTO);

        // Act & Assert
        mockMvc.perform(get("/api/user/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId", is(1)))
                .andExpect(jsonPath("$.name", is("Test User")));

        verify(userService, times(1)).getUserById(1L);
    }

    @Test
    void testGetAllUsers() throws Exception {
        // Arrange
        List<UserResponseDTO> users = Arrays.asList(
                new UserResponseDTO(1L, "User1", "user1@example.com", Role.USER, "111"),
                new UserResponseDTO(2L, "User2", "user2@example.com", Role.USER, "222")
        );
        when(userService.getAllUsers()).thenReturn(users);

        // Act & Assert
        mockMvc.perform(get("/api/user/users")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()", is(2)))
                .andExpect(jsonPath("$[0].name", is("User1")));

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    void testGetAllManagers() throws Exception {
        // Arrange
        List<UserResponseDTO> managers = Arrays.asList(
                new UserResponseDTO(3L, "Manager1", "manager1@example.com", Role.MANAGER, "333"),
                new UserResponseDTO(4L, "Manager2", "manager2@example.com", Role.MANAGER, "444")
        );
        when(userService.getAllManagers()).thenReturn(managers);

        // Act & Assert
        mockMvc.perform(get("/api/user/managers")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()", is(2)))
                .andExpect(jsonPath("$[0].name", is("Manager1")));

        verify(userService, times(1)).getAllManagers();
    }
}