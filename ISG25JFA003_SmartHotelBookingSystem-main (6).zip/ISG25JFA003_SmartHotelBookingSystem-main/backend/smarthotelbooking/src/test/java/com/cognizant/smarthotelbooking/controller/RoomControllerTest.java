package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;
import com.cognizant.smarthotelbooking.service.RoomService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class RoomControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RoomService roomService;

    @InjectMocks
    private RoomController roomController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(roomController).build();
    }

    private RoomResponseDTO buildRoom(Long id, String type, double price, boolean available, Long hotelId) {
        RoomResponseDTO dto = new RoomResponseDTO();
        dto.setId(id);
        dto.setType(type);
        dto.setPrice(price);
        dto.setAvailable(available);
        dto.setHotelId(hotelId);
        return dto;
    }

    @Test
    void testGetAllRooms() throws Exception {
        List<RoomResponseDTO> rooms = Arrays.asList(
                buildRoom(1L, "Deluxe", 5000.0, true, 1L),
                buildRoom(2L, "Suite", 8000.0, false, 1L)
        );

        when(roomService.getAllRooms()).thenReturn(rooms);

        mockMvc.perform(get("/api/rooms"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].type").value("Deluxe"));
    }

    @Test
    void testGetRoomById() throws Exception {
        RoomResponseDTO room = buildRoom(1L, "Deluxe", 5000.0, true, 1L);

        when(roomService.getRoomById(1L)).thenReturn(room);

        mockMvc.perform(get("/api/rooms/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("Deluxe"))
                .andExpect(jsonPath("$.price").value(5000.0));
    }

    @Test
    void testCreateRoom() throws Exception {
        RoomResponseDTO createdRoom = buildRoom(3L, "Standard", 3000.0, true, 1L);

        when(roomService.createRoom(any())).thenReturn(createdRoom);

        mockMvc.perform(post("/api/rooms")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"type\":\"Standard\",\"price\":3000.0,\"available\":true,\"hotelId\":1}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("Standard"))
                .andExpect(jsonPath("$.price").value(3000.0));
    }

    @Test
    void testUpdateRoom() throws Exception {
        RoomResponseDTO updatedRoom = buildRoom(1L, "Deluxe Updated", 5500.0, true, 1L);

        when(roomService.updateRoom(eq(1L), any())).thenReturn(updatedRoom);

        mockMvc.perform(put("/api/rooms/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"type\":\"Deluxe Updated\",\"price\":5500.0,\"available\":true,\"hotelId\":1}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("Deluxe Updated"));
    }

    @Test
    void testDeleteRoom() throws Exception {
        mockMvc.perform(delete("/api/rooms/1"))
                .andExpect(status().isOk());
    }
}