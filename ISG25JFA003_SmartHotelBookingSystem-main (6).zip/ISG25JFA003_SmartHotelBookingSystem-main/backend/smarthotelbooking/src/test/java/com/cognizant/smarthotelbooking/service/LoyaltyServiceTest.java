package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;
import com.cognizant.smarthotelbooking.entity.*;
import com.cognizant.smarthotelbooking.entity.enums.Action;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.repository.*;
import com.cognizant.smarthotelbooking.service.impl.LoyaltyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LoyaltyServiceTest {
    @Mock
    private LoyaltyAccountRepository loyaltyAccountRepository;
    @Mock
    private LoyaltyTransactionRepository loyaltyTransactionRepository;
    @Mock
    private RedemptionRepository redemptionRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private PaymentRepository paymentRepository;

    @InjectMocks
    private LoyaltyServiceImpl loyaltyService;

    private User user;
    private LoyaltyAccount loyaltyAccount;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId(1L);
        user.setEmail("test@test.com");

        loyaltyAccount = new LoyaltyAccount();
        loyaltyAccount.setLoyaltyId(1L);
        loyaltyAccount.setUser(user);
        loyaltyAccount.setPointsBalance(100);
        loyaltyAccount.setLastUpdated(LocalDateTime.now());
    }

    @Nested
    class PointRedemptionTests {
        @Mock
        private SecurityContext securityContext;
        @Mock
        private Authentication authentication;

        @Test
        void redeemPoints_shouldSuccessfullyRedeemPoints() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");
                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(user));

                LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO(1L, 1L, 0.0, 50);
                Booking booking = new Booking();
                booking.setBookingId(1L);
                booking.setStatus(BookingStatus.PENDING);
                Payment payment = new Payment();
                payment.setAmount(100.0);
                payment.setBooking(booking);

                when(loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId())).thenReturn(loyaltyAccount);
                when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
                when(paymentRepository.findByBooking_BookingId(1L)).thenReturn(payment);
                when(loyaltyAccountRepository.save(any(LoyaltyAccount.class))).thenReturn(loyaltyAccount);
                when(redemptionRepository.save(any(Redemption.class))).thenReturn(new Redemption());
                when(loyaltyTransactionRepository.save(any(LoyaltyTransaction.class))).thenReturn(new LoyaltyTransaction());
                when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
                when(paymentRepository.save(any(Payment.class))).thenReturn(payment);

                LoyaltyResponseDTO response = loyaltyService.redeemPoints(requestDTO);

                assertNotNull(response);
                assertEquals(user.getUserId(), response.getUserId());
                assertEquals(50, response.getPointsBalance());
                assertEquals("Points redeemed successfully", response.getMessage());
                assertEquals(BookingStatus.CONFIRMED, booking.getStatus());
                assertEquals(50.0, payment.getAmount());
                verify(loyaltyAccountRepository, times(1)).save(any(LoyaltyAccount.class));
                verify(bookingRepository, times(1)).save(any(Booking.class));
                verify(paymentRepository, times(1)).save(any(Payment.class));
                verify(redemptionRepository, times(1)).save(any(Redemption.class));
                verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
            }
        }

        @Test
        void redeemPoints_shouldThrowException_whenInsufficientPoints() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");
                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(user));

                LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO(1L, 1L, 0.0, 150);
                when(loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId())).thenReturn(loyaltyAccount);

                IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                        loyaltyService.redeemPoints(requestDTO)
                );

                assertEquals("Invalid arguments: Insufficient points", exception.getMessage());
                verify(loyaltyAccountRepository, never()).save(any());
                verify(redemptionRepository, never()).save(any());
                verify(loyaltyTransactionRepository, never()).save(any());
            }
        }

        @Test
        void redeemPoints_shouldThrowException_whenBookingNotFound() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");
                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(user));

                LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO(1L, 1L, 0.0, 50);
                when(loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId())).thenReturn(loyaltyAccount);
                when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

                BookingNotFoundException exception = assertThrows(BookingNotFoundException.class, () ->
                        loyaltyService.redeemPoints(requestDTO)
                );

                assertEquals("Booking not found", exception.getMessage());
                verify(redemptionRepository, never()).save(any());
                verify(loyaltyTransactionRepository, never()).save(any());
            }
        }
    }

    @Test
    void getPointsBalance_shouldReturnCorrectBalance() {
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);

        LoyaltyResponseDTO response = loyaltyService.getPointsBalance(1L);

        assertNotNull(response);
        assertEquals(1L, response.getUserId());
        assertEquals(100, response.getPointsBalance());
        verify(loyaltyAccountRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void getTransactionHistory_shouldReturnHistory() {
        LoyaltyTransaction transaction1 = new LoyaltyTransaction();
        transaction1.setUser(user);
        transaction1.setAction(Action.EARN);
        transaction1.setDescription("Earned points from booking");
        transaction1.setPoints(10);
        transaction1.setTimestamp(LocalDateTime.now());
        List<LoyaltyTransaction> transactions = List.of(transaction1);

        when(loyaltyTransactionRepository.findByUser_UserId(1L)).thenReturn(transactions);

        List<LoyaltyTransactionDTO> result = loyaltyService.getTransactionHistory(1L);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("Earned points from booking", result.get(0).getDescription());
        assertEquals(10, result.get(0).getPoints());
        verify(loyaltyTransactionRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void getTransactionHistory_shouldReturnEmptyList_whenNoTransactionsFound() {
        when(loyaltyTransactionRepository.findByUser_UserId(1L)).thenReturn(Collections.emptyList());

        List<LoyaltyTransactionDTO> result = loyaltyService.getTransactionHistory(1L);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(loyaltyTransactionRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void earnPoints_shouldIncreasePointsBalance() {
        LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO(1L, 0L, 200.0, 0);

        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);
        when(loyaltyAccountRepository.save(any(LoyaltyAccount.class))).thenReturn(loyaltyAccount);
        when(loyaltyTransactionRepository.save(any(LoyaltyTransaction.class))).thenReturn(new LoyaltyTransaction());

        LoyaltyResponseDTO response = loyaltyService.earnPoints(requestDTO);

        assertNotNull(response);
        assertEquals(120, response.getPointsBalance());
        assertEquals("Points earned successfully", response.getMessage());
        verify(loyaltyAccountRepository, times(1)).save(any(LoyaltyAccount.class));
        verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
    }
}