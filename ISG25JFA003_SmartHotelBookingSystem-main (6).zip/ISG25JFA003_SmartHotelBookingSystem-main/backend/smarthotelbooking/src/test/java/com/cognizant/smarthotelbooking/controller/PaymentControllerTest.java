package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.PaymentRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.PaymentResponseDTO;
import com.cognizant.smarthotelbooking.entity.Payment;
import com.cognizant.smarthotelbooking.entity.enums.PaymentStatus;
import com.cognizant.smarthotelbooking.exception.PaymentNotFoundException; // <-- New import
import com.cognizant.smarthotelbooking.service.PaymentService;
import com.cognizant.smarthotelbooking.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PaymentController.class)
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PaymentService paymentService;

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private UserDetailsService userDetailsService;

    @MockBean
    private AuthenticationManager authenticationManager;

    @Autowired
    private ObjectMapper objectMapper;

    private PaymentRequestDTO paymentRequestDTO;
    private PaymentResponseDTO paymentResponseDTO;
    private Payment mockPayment;
    private long testPaymentId;
    private long testBookingId;

    @BeforeEach
    void setUp() {
        testPaymentId = 1L;
        testBookingId = 101L;

        paymentRequestDTO = new PaymentRequestDTO();
        paymentRequestDTO.setBookingId(testBookingId);
        paymentRequestDTO.setPaymentMethod("Credit Card");

        paymentResponseDTO = new PaymentResponseDTO();
        paymentResponseDTO.setPaymentId(testPaymentId);
        paymentResponseDTO.setBookingId(testBookingId);
        paymentResponseDTO.setAmount(100.0);
        paymentResponseDTO.setPaymentDate(LocalDate.now());
        paymentResponseDTO.setPaymentMethod("Credit Card");
        paymentResponseDTO.setPaymentStatus(PaymentStatus.SUCCESS.name());

        mockPayment = new Payment();
        mockPayment.setPaymentId(testPaymentId);
        mockPayment.setAmount(100.0);
        mockPayment.setPaymentDate(LocalDate.now());
        mockPayment.setPaymentMethod("Credit Card");
        mockPayment.setPaymentStatus(PaymentStatus.SUCCESS);
    }

    @Test
    @WithMockUser(username = "testuser", roles = {"USER", "ADMIN"})
    void processPayment_shouldReturnOk() throws Exception {
        when(paymentService.processPayment(any(PaymentRequestDTO.class))).thenReturn(paymentResponseDTO);

        mockMvc.perform(post("/api/payments/process")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(paymentRequestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.paymentId", is((int) testPaymentId)))
                .andExpect(jsonPath("$.bookingId", is((int) testBookingId)));
    }

    @Test
    @WithMockUser(username = "testuser", roles = {"USER", "ADMIN"})
    void getPayment_shouldReturnOk() throws Exception {
        when(paymentService.getPaymentById(eq(String.valueOf(testPaymentId)))).thenReturn(paymentResponseDTO);

        mockMvc.perform(get("/api/payments/{paymentId}", testPaymentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.paymentId", is((int) testPaymentId)))
                .andExpect(jsonPath("$.paymentStatus", is(PaymentStatus.SUCCESS.name())));
    }

    @Test
    @WithMockUser(username = "testuser", roles = {"USER", "ADMIN"})
    void getPaymentByBooking_shouldReturnOk() throws Exception {
        when(paymentService.getPaymentByBookingId(eq(String.valueOf(testBookingId)))).thenReturn(paymentResponseDTO);

        mockMvc.perform(get("/api/payments/booking/{bookingId}", testBookingId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bookingId", is((int) testBookingId)))
                .andExpect(jsonPath("$.paymentStatus", is(PaymentStatus.SUCCESS.name())));
    }

    @Test
    @WithMockUser(username = "testuser", roles = {"USER", "ADMIN"})
    void getAllPayments_shouldReturnOk() throws Exception {
        List<Payment> payments = Collections.singletonList(mockPayment);
        when(paymentService.getAllPayments()).thenReturn(payments);

        mockMvc.perform(get("/api/payments/get-payments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()", is(1)))
                .andExpect(jsonPath("$[0].paymentId", is((int) testPaymentId)));
    }

    @Test
    @WithMockUser(username = "testuser", roles = {"USER", "ADMIN"})
    void getPayment_shouldReturnNotFound_whenPaymentDoesNotExist() throws Exception {
        when(paymentService.getPaymentById(any(String.class)))
                .thenThrow(new PaymentNotFoundException("Payment not found")); // <-- Throw the correct exception

        mockMvc.perform(get("/api/payments/{paymentId}", 999L))
                .andExpect(status().isNotFound()); // <-- Expect a 404, which will now work
    }

    // You can safely remove the nested class from here
}