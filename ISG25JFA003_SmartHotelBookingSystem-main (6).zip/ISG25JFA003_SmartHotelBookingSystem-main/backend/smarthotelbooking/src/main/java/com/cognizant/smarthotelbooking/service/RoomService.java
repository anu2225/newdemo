package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.RoomRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;

import java.util.List;

public interface RoomService {
    RoomResponseDTO createRoom(RoomRequestDTO roomRequestDTO);
    RoomResponseDTO updateRoom(Long roomId, RoomRequestDTO roomRequestDTO);
    void deleteRoom(Long roomId);
    RoomResponseDTO getRoomById(Long roomId);
    List<RoomResponseDTO> getAllRooms();
    List<RoomResponseDTO> getRoomsByHotel(Long hotelId);
    List<RoomResponseDTO> filterByPrice(Double min, Double max);
    List<RoomResponseDTO> getAvailableRooms();
}