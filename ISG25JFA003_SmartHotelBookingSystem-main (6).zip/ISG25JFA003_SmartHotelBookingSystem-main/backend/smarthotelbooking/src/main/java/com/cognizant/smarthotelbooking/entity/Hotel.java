package com.cognizant.smarthotelbooking.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "hotels")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Hotel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long hotelId;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false)
    private String location;

    private String amenities;   // comma separated or JSON string depending on frontend
    private Double rating;
    private long managerId;
}

