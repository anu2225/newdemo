package com.cognizant.smarthotelbooking.dto.responsedto;

import com.cognizant.smarthotelbooking.entity.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserResponseDTO {
    private long userId;
    private String name;
    private String email;
    private Role role;
    private String contactNumber;
}
