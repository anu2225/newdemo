package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.service.impl.AdminServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@RestController
@Slf4j
public class AdminController {

    private final AdminServiceImpl adminService;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create-manager-account")
    public ResponseEntity<String> createManager(@Valid @RequestBody UserRegistrationDTO request) {
        log.info("Creating Manager {}", request.getName());
        adminService.createManager(request);
        return ResponseEntity.ok("Hotel Manager account created successfully!");
    }
}
