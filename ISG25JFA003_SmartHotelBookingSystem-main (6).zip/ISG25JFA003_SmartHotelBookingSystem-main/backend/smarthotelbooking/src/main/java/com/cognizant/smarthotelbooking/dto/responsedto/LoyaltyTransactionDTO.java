package com.cognizant.smarthotelbooking.dto.responsedto;

import com.cognizant.smarthotelbooking.entity.enums.Action;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LoyaltyTransactionDTO {
    private Action action;
    private String description;
    private int points;
    private LocalDateTime timestamp;
}
