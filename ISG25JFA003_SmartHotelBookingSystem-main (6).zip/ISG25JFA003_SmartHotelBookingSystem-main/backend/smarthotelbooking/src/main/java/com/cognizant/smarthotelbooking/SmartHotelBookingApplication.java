package com.cognizant.smarthotelbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartHotelBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartHotelBookingApplication.class, args);
	}

}
