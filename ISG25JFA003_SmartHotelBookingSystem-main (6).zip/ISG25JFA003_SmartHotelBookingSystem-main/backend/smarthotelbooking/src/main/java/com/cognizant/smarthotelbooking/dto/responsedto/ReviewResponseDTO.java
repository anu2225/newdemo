package com.cognizant.smarthotelbooking.dto.responsedto;


import com.cognizant.smarthotelbooking.entity.Review;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReviewResponseDTO {
    private Long reviewId;
    private Long userId;
    private Long hotelId;
    private double rating;
    private String comment;
    private String response;
    private LocalDateTime timestamp;

    public ReviewResponseDTO(Review review) {
        this.reviewId = review.getReviewId();
        this.userId = review.getUser().getUserId();
        this.hotelId = review.getHotel().getHotelId();
        this.rating = review.getRating();
        this.comment = review.getComment();
        this.response = review.getResponse();
        this.timestamp = review.getTimestamp();
    }

}
