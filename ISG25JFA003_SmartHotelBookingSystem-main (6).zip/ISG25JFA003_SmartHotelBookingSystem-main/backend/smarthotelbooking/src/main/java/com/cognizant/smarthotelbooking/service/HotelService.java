package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.HotelRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.HotelResponseDTO;

import java.util.List;

public interface HotelService {
    HotelResponseDTO createHotel(HotelRequestDTO dto);
    HotelResponseDTO updateHotel(Long id, HotelRequestDTO dto);
    void deleteHotel(Long id);
    HotelResponseDTO getHotelById(Long id);
    List<HotelResponseDTO> getAllHotels();
    List<HotelResponseDTO> searchByLocation(String location);
    List<HotelResponseDTO> filterByRating(Double minRating);
}