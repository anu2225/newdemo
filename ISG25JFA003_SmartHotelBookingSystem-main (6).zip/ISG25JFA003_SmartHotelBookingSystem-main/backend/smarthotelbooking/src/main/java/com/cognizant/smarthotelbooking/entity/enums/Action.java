package com.cognizant.smarthotelbooking.entity.enums;

public enum Action {
    EARN,
    REDEEM
}
