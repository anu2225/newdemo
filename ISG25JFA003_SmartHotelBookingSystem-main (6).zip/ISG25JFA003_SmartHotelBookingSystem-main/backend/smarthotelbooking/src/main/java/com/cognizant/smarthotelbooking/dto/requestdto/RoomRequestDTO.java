package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomRequestDTO {
    @NotBlank(message = "Give a specific room type")
    private String type;
    @NotNull(message = "Price cannot be null")
    private double price;
    @NotBlank(message = "availability cannot be null")
    private boolean availability;
    @NotBlank(message = "Features cannot be null")
    private String features;
    @NotBlank(message = "Hotel Id cannot be null")
    private Long hotelId;
}

