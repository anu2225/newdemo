package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoyaltyRequestDTO {
    private Long userId;
    @NotNull(message = "Booking Id is required")
    private Long bookingId;
    private Double amount;
    @NotNull(message = "Points cannot be null")
    private int points;
    }
