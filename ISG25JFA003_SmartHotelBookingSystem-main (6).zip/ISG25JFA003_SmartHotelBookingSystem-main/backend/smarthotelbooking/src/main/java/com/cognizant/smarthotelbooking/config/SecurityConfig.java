package com.cognizant.smarthotelbooking.config;

import com.cognizant.smarthotelbooking.util.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final CustomAuthenticationEntryPoint authenticationEntryPoint;


    @Bean
    protected SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
         http
                .csrf(AbstractHttpConfigurer::disable)
                 .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(request -> request
                        .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                        .requestMatchers("/api/auth/**").permitAll() // Handles /api/auth/*
                        .requestMatchers("/api/admin/**").hasRole("ADMIN") // Handles /api/admin/*
                        .requestMatchers("/api/bookings/create").hasRole("USER") // For createBooking
                        .requestMatchers(HttpMethod.GET, "/api/bookings").hasRole("ADMIN") // For getAllBookings
                        .requestMatchers(HttpMethod.GET, "/api/bookings/{bookingId}").hasAnyRole("ADMIN", "MANAGER") // For getBooking
                        .requestMatchers(HttpMethod.GET, "/api/bookings/user/{userId}").hasAnyRole("ADMIN", "USER", "MANAGER") // For getBookingsByUser
                        .requestMatchers(HttpMethod.DELETE, "/api/bookings/{bookingId}").hasRole("USER") // For cancelBooking
                        .requestMatchers("/api/payments/process").hasRole("USER") // For processPayment
                        .requestMatchers(HttpMethod.GET, "/api/payments/get-payments").hasRole("ADMIN") // For getAllPayments
                        .requestMatchers(HttpMethod.GET, "/api/payments/{paymentId}").hasAnyRole("USER", "ADMIN", "MANAGER") // For getPayment
                        .requestMatchers(HttpMethod.GET, "/api/payments/booking/{bookingId}").hasAnyRole("ADMIN", "MANAGER") // For getPaymentByBooking
                        .requestMatchers(HttpMethod.POST, "/api/reviews").hasRole("USER") // For submitReview
                        .requestMatchers(HttpMethod.POST, "/api/reviews/{reviewId}/response").hasRole("MANAGER") // For respondToReview
                        .requestMatchers(HttpMethod.DELETE, "/api/reviews/{reviewId}").hasRole("MANAGER") // For deleteReview
                        .requestMatchers(HttpMethod.POST, "/api/rooms").hasRole("MANAGER") // For createRoom
                        .requestMatchers(HttpMethod.PUT, "/api/rooms/{id}").hasRole("MANAGER") // For updateRoom
                        .requestMatchers(HttpMethod.DELETE, "/api/rooms/{id}").hasRole("MANAGER") // For deleteRoom
                        .requestMatchers(HttpMethod.POST, "/api/hotels").hasRole("MANAGER") // For createHotel
                        .requestMatchers(HttpMethod.PUT, "/api/hotels/{id}").hasRole("MANAGER") // For updateHotelById
                        .requestMatchers(HttpMethod.DELETE, "/api/hotels/{id}").hasRole("MANAGER") // For deleteHotel
                        .requestMatchers("/api/user/users").hasRole("ADMIN") // For getAllUsers
                        .requestMatchers("/api/user/managers").hasRole("ADMIN") // For getAllManagers
                        .requestMatchers(HttpMethod.GET, "/api/user/{id}").hasAnyRole("ADMIN", "USER", "MANAGER") // For getUserById
                        .requestMatchers("/api/rewards/**").hasRole("USER") // For all rewards endpoints
                        .anyRequest().authenticated())
                .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                 .exceptionHandling(ex -> ex.authenticationEntryPoint(authenticationEntryPoint)) // handle 401
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
    @Bean
    protected PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UrlBasedCorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:4200")); // Allow frontend origin
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE")); // Allow necessary methods
        config.setAllowedHeaders(List.of("*")); // Allow all headers
        config.setAllowCredentials(true); // Enable credentials
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }


}
