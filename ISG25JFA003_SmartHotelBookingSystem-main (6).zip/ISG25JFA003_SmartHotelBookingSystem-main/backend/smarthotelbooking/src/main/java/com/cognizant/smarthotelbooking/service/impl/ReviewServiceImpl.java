package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.Review;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.HotelNotFoundException;
import com.cognizant.smarthotelbooking.exception.ReviewNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.ReviewRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final UserRepository userRepository;
    private final HotelRepository hotelRepository;
    private final ReviewRepository reviewRepository;

    @Override
    public ReviewResponseDTO createReview(ReviewRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() ->
                new UserNotFoundException("User not logged in")
        );
        Hotel hotel = hotelRepository.findById(dto.getHotelId()).orElseThrow(
                () -> new HotelNotFoundException("Hotel not found")
        );
        Review review = new Review();
        review.setRating(dto.getRating());
        review.setTimestamp(LocalDateTime.now());
        review.setComment(dto.getComment());
        review.setUser(user);
        review.setHotel(hotel);


        return new ReviewResponseDTO(reviewRepository.save(review));
    }


    @Override
    public List<ReviewResponseDTO> getReviewsByHotel(Long hotelId) {
        List<Review> reviews = reviewRepository.findByHotel_HotelId(hotelId);

        if (reviews.isEmpty()) {
            throw new ReviewNotFoundException("No reviews found for hotel with ID: " + hotelId);
        }

        return reviews.stream()
                .map(ReviewResponseDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public List<ReviewResponseDTO> getReviewsByUser(Long userId) {
        List<Review> reviews = reviewRepository.findByUser_UserId(userId);

        if (reviews.isEmpty()) {
            throw new ReviewNotFoundException("No reviews found for user with ID: " + userId);
        }

        return reviews.stream()
                .map(ReviewResponseDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public ReviewResponseDTO respondToReview(Long reviewId, String response) {
        Review review = reviewRepository.findById(reviewId).orElseThrow(
                () -> new ReviewNotFoundException("Review Not Found")
        );
        review.setResponse(response);
        return new ReviewResponseDTO(reviewRepository.save(review));
    }

    @Override
    public ReviewResponseDTO updateResponse(Long reviewId, String response) {
        return respondToReview(reviewId, response);
    }

    @Override
    public void deleteReview(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }
}
