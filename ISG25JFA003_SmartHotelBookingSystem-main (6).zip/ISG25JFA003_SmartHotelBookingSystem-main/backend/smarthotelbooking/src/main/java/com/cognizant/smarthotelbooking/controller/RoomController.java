package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.RoomRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;
import com.cognizant.smarthotelbooking.service.RoomService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
@Slf4j
public class RoomController {

    private final RoomService roomService;

    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public RoomResponseDTO createRoom(@RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.createRoom(roomRequestDTO);
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PutMapping("/{id}")
    public RoomResponseDTO updateRoom(@PathVariable Long id, @RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.updateRoom(id, roomRequestDTO);
    }

    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{id}")
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/{id}")
    public RoomResponseDTO getRoomById(@PathVariable Long id) {
        log.info("Getting room with roomId {} ", id);
        return roomService.getRoomById(id);
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping
    public List<RoomResponseDTO> getAllRooms() {
        log.info("Getting all rooms");
        return roomService.getAllRooms();
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/hotel/{hotelId}")
    public List<RoomResponseDTO> getRoomsByHotel(@PathVariable Long hotelId) {
        log.info("Getting rooms from Hotel with hotelId {}", hotelId);
        return roomService.getRoomsByHotel(hotelId);
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/filter")
    public List<RoomResponseDTO> filterByPrice(@RequestParam Double min, @RequestParam Double max) {
        return roomService.filterByPrice(min, max);
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/available")
    public List<RoomResponseDTO> getAvailableRooms() {
        log.info("Getting available rooms");
        return roomService.getAvailableRooms();
    }
}