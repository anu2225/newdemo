package com.cognizant.smarthotelbooking.entity;

import com.cognizant.smarthotelbooking.entity.enums.Role;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userId")
    private long userId;
    @Column(name = "name", nullable = false, length = 40)
    private String name;
    @Column(name = "email", unique = true, nullable = false)
    private String email;
    @Column(name = "password", nullable = false)
    private String password;
    @Column(name = "role", nullable = false)
    @Enumerated(EnumType.STRING)
    private Role role;
    @Column(name = "contactNumber",nullable = false, length = 10)
    private String contactNumber;

    private boolean active = true;

    @OneToMany(mappedBy = "user")
    private List<Booking> bookingList;

    @OneToMany(mappedBy = "user")
    private List<Payment> paymentList;

    @OneToMany(mappedBy = "user")
    private List<Review> reviewList;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private LoyaltyAccount loyaltyAccount;

    @OneToMany(mappedBy = "user")
    private List<LoyaltyTransaction> loyaltyTransactionList;
}
