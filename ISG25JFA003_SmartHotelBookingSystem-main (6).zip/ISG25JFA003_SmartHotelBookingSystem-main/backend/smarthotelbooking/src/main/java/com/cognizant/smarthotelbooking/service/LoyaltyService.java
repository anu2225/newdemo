package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;

import java.util.List;

public interface LoyaltyService {
    LoyaltyResponseDTO getPointsBalance(Long userId);
    LoyaltyResponseDTO redeemPoints(LoyaltyRequestDTO requestDTO);
    List<LoyaltyTransactionDTO> getTransactionHistory(Long userId);
    LoyaltyResponseDTO earnPoints(LoyaltyRequestDTO requestDTO);
    LoyaltyResponseDTO applyPointsToBooking(LoyaltyRequestDTO requestDTO);
}
