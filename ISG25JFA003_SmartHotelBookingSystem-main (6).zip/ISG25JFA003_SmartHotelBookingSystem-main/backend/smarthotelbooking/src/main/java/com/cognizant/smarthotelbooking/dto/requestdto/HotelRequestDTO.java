package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HotelRequestDTO {
    @NotBlank(message = "Hotel name is required")
    private String name;
    @NotBlank(message = "location is required")
    private String location;
    @NotBlank(message = "facilities is required")
    private String amenities;
    @NotNull(message = "Rating is required")
    @Max(value = 5, message = "rating should be given out of 5")
    private Double rating;
}