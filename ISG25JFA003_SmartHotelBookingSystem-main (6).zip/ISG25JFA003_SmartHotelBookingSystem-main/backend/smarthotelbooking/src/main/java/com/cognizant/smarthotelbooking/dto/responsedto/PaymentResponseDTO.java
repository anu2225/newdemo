package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class PaymentResponseDTO {
    private Long paymentId;
    private Long bookingId;
    private Double amount;
    private LocalDate paymentDate;
    private String paymentMethod;
    private String paymentStatus;
}
