package com.cognizant.smarthotelbooking.repository;

import com.cognizant.smarthotelbooking.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    @Query("SELECT p FROM Payment p JOIN p.user u WHERE u.email = :email")
    List<Payment> findPaymentsByUserEmail(String email);

    Payment findByBooking_BookingId(Long bookingId);
}
