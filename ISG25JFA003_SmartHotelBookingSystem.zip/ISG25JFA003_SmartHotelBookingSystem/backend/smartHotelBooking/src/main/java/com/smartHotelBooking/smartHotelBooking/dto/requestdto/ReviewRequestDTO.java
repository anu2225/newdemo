package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

@Data
public class ReviewRequestDTO {
    private Long userId;
    private Long hotelId;
    private int rating;
    private String comment;
}
