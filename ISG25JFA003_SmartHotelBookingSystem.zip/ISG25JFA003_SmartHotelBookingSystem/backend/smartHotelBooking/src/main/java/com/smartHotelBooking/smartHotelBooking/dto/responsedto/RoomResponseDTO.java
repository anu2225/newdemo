package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

@Data
public class RoomResponseDTO {
    private Long roomId;
    private String type;
    private double price;
    private boolean availability;
    private String features;
    private Long hotelId;

}