package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.entity.enums.Role;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.UserService;
import com.smartHotelBooking.smartHotelBooking.util.UserInfoDetails;
import jakarta.validation.Valid;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
           User user = userRepository.findByEmail(username)
                       .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));

           if(!user.isActive() && user.getRole() != Role.ADMIN) {
               throw new BadCredentialsException("Account is inactive");
           }

           return new UserInfoDetails(user);
    }


    @Override
    public void registerUser(@Valid UserRegistrationDTO request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole() != null ? request.getRole() : Role.USER);
        user.setContactNumber(request.getContactNumber());


        userRepository.save(user);
    }

    @Override
    public Optional<User> getUserById(int id) {
        return Optional.of(userRepository.findById(id))
                .orElseThrow(() -> new UsernameNotFoundException("Not Found"));
    }

}
