package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PaymentRequestDTO {
    private Long bookingId;
    private Double amount;
    private LocalDateTime paymentDate;
    private String paymentMethod;
    private String paymentStatus;
}
