package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

@Data
public class HotelRequestDTO {
    private Long hotelId;
    private String name;
    private String location;
    private String amenities;
    private double rating;
    private Long managerId;


}