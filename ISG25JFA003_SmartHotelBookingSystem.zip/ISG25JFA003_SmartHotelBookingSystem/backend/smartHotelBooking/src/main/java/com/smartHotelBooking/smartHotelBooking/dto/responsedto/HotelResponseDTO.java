package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

@Data
public class HotelResponseDTO {
    private Long hotelId;
    private String name;
    private String location;
    private String amenities;
    private double rating;
    private Long managerId;
}