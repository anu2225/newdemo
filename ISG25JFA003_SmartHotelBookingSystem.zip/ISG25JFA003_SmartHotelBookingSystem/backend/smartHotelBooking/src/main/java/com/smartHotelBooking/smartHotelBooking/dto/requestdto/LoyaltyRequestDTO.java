package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

@Data
public class LoyaltyRequestDTO {
    private Long userId;
    private Long bookingId;
    private Double amount;
    private int points;
    }
