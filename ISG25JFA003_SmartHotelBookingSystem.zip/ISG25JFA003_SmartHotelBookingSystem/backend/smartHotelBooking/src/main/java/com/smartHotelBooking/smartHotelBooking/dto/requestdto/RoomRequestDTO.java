package com.SmartHotelBookingSystem.dto.requestdto;

import lombok.Data;

@Data
public class RoomRequestDTO {

    private Integer roomId;
    private String type;
    private double price;
    private boolean availability;
    private String features;


}