package com.smartHotelBooking.smartHotelBooking.service;

import org.springframework.security.authentication.AuthenticationManager;

public interface AuthService {

    


}
